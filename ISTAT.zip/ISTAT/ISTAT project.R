library(tidyverse)
getwd()
setwd("C:/Users/valer/Downloads")
data <- readxl::read_excel('ISTAT.xlsx')
colnames(data)

#QUESITO: cosa influisce sulla volont�� di avere figli
#EDA: explanatory data analysis

View(data)

#WHO WANT TO HAVE KIDS?
data$fer_int_d <- as.factor(data$fer_int_d)
ggplot(data, aes(x = fer_int_d)) + geom_bar()
drop <- which(is.na(data$fer_int_d))
#rows with null values to be cancelled
length(na.omit(data$fer_int_d))

data <- data[-drop,]
ggplot(data, aes(x=fer_int_d)) + geom_bar()
#More people want to have kids than who dont want to have kids

#1. General gender differences

#there are in generale more female responses
gender_differences <- data %>% group_by(Gender = data$gender, fer_int_d) %>% 
  summarise(Count = n()) %>% mutate(Percentage= Count/sum(Count)*100)
ggplot(gender_differences, aes(x = factor(Gender), y = Percentage, fill = factor(fer_int_d))) +
  geom_bar(stat = "identity")
#more women want to have children
#percentages used because the number of observations is different for men and women

#2. Age group differences
#age group composition
age_differences <- data%>% select(fer_int_d) %>% group_by(Age_group = data$agegr5, fer_int_d) %>% 
  summarise(Count = n()) %>% mutate(Percentage = Count/sum(Count)*100)
ggplot(age_differences, aes(x = factor(Age_group), y = Percentage, fill = factor(fer_int_d)))+
         geom_bar(stat = 'identity')
#1 = 18-24
#2 = 25-29
#3 = 30-34
#4 = 35-39
#5 = 40-45
#6 = 45-49

#3. If they already have kids 
kids_differences <- data%>% select(fer_int_d) %>% group_by(Has_kids = data$ch_dummy, fer_int_d) %>%
  summarise(Count = n()) %>% mutate(Percentage= Count/sum(Count)*100)
ggplot(kids_differences, aes(x = factor(Has_kids), y = Percentage, fill = factor(fer_int_d)))+
         geom_bar(stat='identity', position = 'stack', na.rm=TRUE)
#4.N of kids 
kids_number_differences <- data%>% select(fer_int_d) %>% group_by(Has_kids = data$ch_nb, fer_int_d) %>%
  summarise(Count = n()) %>% mutate(Percentage= Count/sum(Count)*100)
ggplot(kids_number_differences, aes(x = factor(Has_kids), y = Percentage, fill = factor(fer_int_d)))+
  geom_bar(stat='identity', position = 'stack', na.rm=TRUE)

#categorical variables:
data <- data %>% mutate(across(all_of(names(data)), as.factor))
data$weight <- as.numeric(data$weight)
data$id <- as.numeric(data$id)
categorical_vars <- which(sapply(data, is.factor))
data_factors <- data[,categorical_vars]
data_factors <- data %>% select(-'country', -'countrybirth', -'gender', -'agegr5', 
                              -'ch_dummy', -'id', -'weight')

# Let's assume your dataset is called `data`
vars <- colnames(data_factors)  # List of all categorical variables
n <- length(data_factors)

# Empty matrix to store Cram??????r's V values
correlation_matrix <- matrix(NA, nrow = n, ncol = n)
colnames(correlation_matrix) <- vars
rownames(correlation_matrix) <- vars
library(vcd)
# Calculate Cram??????r's V for each pair of variables
for (i in 1:(n-1)) {
  for (j in (i+1):n) {
    # Create contingency table
    contingency_table <- table(data_factors[[vars[i]]], data_factors[[vars[j]]])
    
    # Calculate Cram??????r's V
    cramers_v <- assocstats(contingency_table)$cramer
    correlation_matrix[i, j] <- cramers_v
    correlation_matrix[j, i] <- cramers_v
  }
}

# Set diagonal to 1 (Cram??????r's V of a variable with itself)
diag(correlation_matrix) <- 1


# Display the correlation matrix of Cram??????r's V values
print(correlation_matrix)

#there is clearly strong association among some predictors. 
# Assuming 'correlation_matrix' is your matrix of Cram??????r's V values
threshold <- 0.9
high_assoc_pairs <- which(correlation_matrix > threshold, arr.ind = TRUE)

# Initialize a vector to keep track of variables to remove
vars_to_remove <- c()
# Loop through each pair
for (i in 1:nrow(high_assoc_pairs)) {
  var1 <- rownames(correlation_matrix)[high_assoc_pairs[i, 1]]
  var2 <- colnames(correlation_matrix)[high_assoc_pairs[i, 2]]
  
  # Decide which variable to remove based on your criteria
  # For example, remove var2
  vars_to_remove <- c(vars_to_remove, var2)
}
#show the columns that are more present
table(vars_to_remove)       

#these variables are multicollinear, so in the regression we will select only few of them. 
library(FactoMineR)
library(factoextra)

mca_result <- MCA(data_factors, quanti.sup = NULL, quali.sup = c(1), graph = FALSE)
fviz_contrib(mca_result, choice = "var", axes = 1, top = 20)
fviz_contrib(mca_result, choice = "var", axes = 2, top = 30) 
fviz_contrib(mca_result, choice = "var", axes = 3, top = 30)
fviz_contrib(mca_result, choice = "var", axes = 4, top = 30)
fviz_contrib(mca_result, choice = "var", axes = 5, top = 30) 
fviz_contrib(mca_result, choice = "var", axes = 6, top = 30) 

#WORK-LIFE BALANCE
#logistic regression on intention to have kids
library(circlize)
work_df <- data %>% select(starts_with('wrk') | edu)

work_influence <- glm(fer_int_d ~ edu+wrk_activity+ 
                        wrk_time+wrk_life_bal1, data = data, family = 'binomial')
summary(work_influence)
library(car)
vif_work <- vif(work_influence)
#edu not relevant, work activity generally relevant except for students, wrk time relevant, 
#the most relevant work time balanced is the number 1. 
#men and women
women_df <- data %>% filter(gender == 2)
men_df <- data %>% filter(gender ==1)
work_influence_women <- glm(fer_int_d ~edu+wrk_activity+ 
                              wrk_time+wrk_life_bal1, data = women_df, family = 'binomial')
work_influence_men <-glm(fer_int_d ~ edu+wrk_activity+ 
                           wrk_time+wrk_life_bal1, data = men_df, family = 'binomial')
summary(work_influence_women)
summary(work_influence_men)
#for women, work time is strongly significant in the impact towards having kids. 
#education is more significant for men. 

#PARTNERSHIP AND CHORES DISTRIBUTION
data$par_dummy <- as.factor(data$par_dummy)
partnership_influence <- glm(fer_int_d ~ par_stat + hh_type+ 
                               hw2 + hw1, data = data, family = 'binomial')
summary(partnership_influence)
vif_partner <- vif(partnership_influence)
#marriage influences the decision, household type as well. 
partnership_influence_women <- glm(fer_int_d ~ par_stat+ hh_type+ hw2 + hw1,
                            data = women_df, family = 'binomial')
summary(partnership_influence_women)
partnership_influence_men <- glm(fer_int_d ~ par_stat + hh_type+ hw2 + hw1,
                                  data = men_df, family = 'binomial')
summary(partnership_influence_men)
#men are very highly influenced by household distribution (it means that the partner does it)

#KIDS AND HAPPINESS
children_influences <- glm(fer_int_d ~ lonely4+ ch_dummy+ch_impact3 + alive_m, 
                        data = data,
                        family = 'binomial')
summary(children_influences)
vif_ch <- vif(children_influences)
#happiness is not relevant, BUT if the mother is alive is very relevant and the ch.impact2 (in terms of
#financial costs)
#but ch_impact3 realize other goals is widely significant.
children_influences_women <- glm(fer_int_d ~ lonely4+ ch_dummy+ch_impact3 + alive_f, 
                           data = women_df,
                           family = 'binomial')
summary(children_influences_women) #for women, father presence is more important
children_influences_men <- glm(fer_int_d ~ lonely4+ ch_dummy+ch_impact3 + alive_f, 
                                 data = men_df,
                                 family = 'binomial')
summary(children_influences_men)
#having the parents alive is very important for men and women. Loneliness is more
#important for women than men. Child impact in terms of realizing other dreams and goals is fundamental for both. 
#being a migrant

values_influences <- glm(fer_int_d ~ countrybirth+ relig+ att_fam4 + att_fam8 , data = data, 
                         family ='binomial')

values_influences2 <- glm(fer_int_d ~ countrybirth+ att_gender4+ att_gender3, data = data, 
                         family ='binomial')

summary(values_influences)
summary(values_influences2)
vif_values <- vif(values_influences)
values_influences_women <- glm(fer_int_d ~ countrybirth+ relig+ att_fam4 + att_fam8, data = women_df, 
                         family ='binomial')
values_influences_men <- glm(fer_int_d ~ countrybirth+ relig+att_fam4+att_fam8, data = men_df, 
                         family ='binomial')

summary(values_influences_women)
summary(values_influences_men)
vif_men <- vif(values_influences_men)
#what is sure is that political idea strongly affect people's position on wanting kids. 
#Men are widely influenced by religion (religion 10 has strong significance), women less. 

# Full logistic regression model (fer_int_d)



# Full logistic regression model (fer_int2)
full_model_fer_int_d <- glm(fer_int_d ~ wrk_time+
                              wrk_activity+par_stat+ 
                             hw1 + lonely4+relig+alive_m,
                           data = data, family = "binomial")
summary(full_model_fer_int_d)
#raggruppare le variabili 

full_women <- glm(fer_int_d ~ wrk_time+
                    wrk_activity+par_stat+ 
                    hw1 + lonely4+relig+alive_m,
                  data = women_df, family = "binomial")

summary(full_women)

full_men <- glm(fer_int_d ~ wrk_time+
                  wrk_activity+par_stat+ 
                  hw1 + lonely4+relig+alive_m,
                data = men_df, family = "binomial")


summary(full_men)
levels(data$fer_int2)
library(MASS)


